--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.10 (Debian 13.10-0+deb11u1)
-- Dumped by pg_dump version 13.10 (Debian 13.10-0+deb11u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE newest;
--
-- Name: newest; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE newest WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE newest OWNER TO postgres;

\connect newest

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: temp_table_info; Type: TYPE; Schema: public; Owner: pcassa
--

CREATE TYPE public.temp_table_info AS (
	t_c_name text,
	t_c_pass text,
	t_c_contact_name text,
	t_c_phone text,
	t_c_email text,
	t_c_inn text,
	t_c_kpp text,
	t_c_k_schet text,
	t_c_r_schet text,
	t_c_bik text,
	t_c_bank_name text,
	t_c_address text
);


ALTER TYPE public.temp_table_info OWNER TO pcassa;

--
-- Name: unique_and_email; Type: TYPE; Schema: public; Owner: pcassa
--

CREATE TYPE public.unique_and_email AS (
	c_unique_id text,
	c_email text
);


ALTER TYPE public.unique_and_email OWNER TO pcassa;

--
-- Name: check_permission(character varying); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.check_permission(admin_l character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare x int;
begin
  select into x case 
    when (select * from (select pt2.permission_id = 1 as tip from admin_table at2
    join privilege_table pt on at2.admin_privilege = pt.privilege_id 
    join permission_table pt2 on pt2.permission_id = pt.privilege_type 
    where at2.admin_login=admin_l) s where tip in (true)) then 1
        else 0
end as is_perm;
return x;
end;
$$;


ALTER FUNCTION public.check_permission(admin_l character varying) OWNER TO pcassa;

--
-- Name: del_tmp_add_company(uuid); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.del_tmp_add_company(temp_id uuid) RETURNS public.unique_and_email
    LANGUAGE plpgsql
    AS $$
DECLARE
temp_info temp_table_info;
res_data unique_and_email;
rand_id int8;
find_id int8;
country_ int;
check_point bool:= false;
diller_id int:=1;
BEGIN 
	--SELECT d_id INTO diller_id FROM diller WHERE d_name = 'EKey';
	/* try to get diller_id for adding to the company table  */
	if diller_id is null then
		return 'ERROR';
	end if;
	select t_c_name,
		   t_c_pass,
		   t_c_contact_name,
		   t_c_phone,
		   t_c_email,
		   t_c_inn,
		   t_c_kpp,
		   t_c_k_schet,
		   t_c_r_schet,
		   t_c_bik,
		   t_c_bank_name,
		   t_c_address
	into temp_info
	FROM temp_company WHERE t_id = temp_id;
    select t_c_country
	into country_
	FROM temp_company WHERE t_id = temp_id;
	--FAILED GETTING INFO/ WRONG temp_id
	IF temp_info.t_c_name IS NULL THEN
	select null,null into res_data;
		RETURN res_data;
	END IF;
	--END 
	WHILE not check_point LOOP
		/* generate random id for company user*/
		SELECT floor(random()* (10000000-99999999 + 1) + 99999999)*100+country_ into rand_id;
		SELECT c_unique_id  INTO find_id FROM company WHERE c_unique_id  = rand_id;--TRY GENERATE AND CHECK ARE THERE similar ID
		
		IF find_id IS NULL THEN
			INSERT INTO company(c_unique_id,
						c_diller_id,
						c_name,
						c_pass,
						c_contact_name,
						c_phone,
						c_email,
						c_inn,
						c_kpp,
						c_k_schet,
						c_r_schet,
						c_bik,
						c_bank_name,
						c_address)
			VALUES(rand_id, 1 ,temp_info.*);
			delete from temp_company where t_id  = temp_id;
		select c_unique_id, c_email into res_data from company where c_unique_id = rand_id;
			check_point := true;
		end if;
		
	END LOOP;
if res_data.c_email is null then
 select null,null into res_data;
else
return res_data;
end if;
END;
$$;


ALTER FUNCTION public.del_tmp_add_company(temp_id uuid) OWNER TO pcassa;

--
-- Name: delete_from_parent(); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.delete_from_parent() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
rec record;
begin
	select t_c_manager_id,t_c_mobile_c_id,t_c_cassa_id,t_c_web_id into rec from tarif_content where
    t_c_id = (select t_c_id_fk from tarif where t_id= old.tarif_id_fk);
   delete from manager_field where m_f_id  = rec.t_c_manager_id;
   delete from mobile_cassa_field where m_c_f_id  = rec.t_c_mobile_c_id;
   delete from cassa_field where c_f_id  = rec.t_c_cassa_id;
   delete from web_manager_field where w_m_f_id  = rec.t_c_web_id;
   return null;
end;
$$;


ALTER FUNCTION public.delete_from_parent() OWNER TO pcassa;

--
-- Name: get_links_state(uuid); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.get_links_state(order_id_ uuid) RETURNS TABLE(cassa_desktop_ text[], cassa_mobile_ text[], web_manager_ text[], mobile_manager_ text[])
    LANGUAGE plpgsql
    AS $$
declare r record;
begin
select 
case 
	when cass_stantion_count >0 then true
	else false
end as cassa_desktop,
case 
	when mobile_cass_count > 0 then true
	else false
end as cassa_mobile,
case 
	when web_manager_count > 0 then true
	else false
end as web_manager,
case 
	when mobile_manager_count > 0 then true
	else false
end as mobile_manager
into r
from saved_order_and_tarif soat where order_id = order_id_;
return query 
select 
case
	when r.cassa_desktop = true then (select product_link from links l where product_id = 1)
	else null
end as cassa_desktop,
case
	when r.cassa_mobile = true then (select product_link from links l where product_id = 2)
	else null
end as cassa_mobile,
case
	when r.web_manager = true then (select product_link from links l where product_id = 3)
	else null
end as web_manager,
case
	when r.mobile_manager = true then (select product_link from links l where product_id = 4)
	else null
end as mobile_manager;
end;
$$;


ALTER FUNCTION public.get_links_state(order_id_ uuid) OWNER TO pcassa;

--
-- Name: get_tarif_details(uuid); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.get_tarif_details(tarif_id uuid) RETURNS TABLE(cass_stantion_c integer, mobile_cassa_c integer, mobile_manager_c integer, web_manager_c integer, order_state boolean, order_end_date character varying)
    LANGUAGE plpgsql
    AS $$
declare 
field_rec record;
begin
return query 
select cass_stantion_count,
mobile_manager_count,
mobile_cass_count,
web_manager_count,
soat.order_state,
case 
	when soat.order_state = true then
		cast ((select end_license from client_tarif where c_t_tarif_id = tarif_id):: DATE as varchar)
		
	else
	null 
end as order_ending
from saved_order_and_tarif soat where tarif_id_fk = tarif_id;
end;
$$;


ALTER FUNCTION public.get_tarif_details(tarif_id uuid) OWNER TO pcassa;

--
-- Name: get_tarifes_for_view(); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.get_tarifes_for_view() RETURNS TABLE(tarif_id uuid, tarif_names character varying[], cassa_names character varying[], tarif_month_prices integer, c_per_price integer, m_per_price integer, w_m_per_price integer, m_c_per_price integer, cassa_counts integer, manager_names character varying[], manager_counts integer, web_names text[], web_counts integer, mobile_cassa_names text[], mobile_cassa_counts integer, tarifes_others text[])
    LANGUAGE plpgsql
    AS $$
--declare 
--tarifes_table_for_return tarifes_table;
begin 
return query SELECT t_id,
	   t_name,
	   c_f_name,
	   t_month_price,
	   cf.c_per_price,
	   mf.m_per_price,
	   wmf.w_m_per_price,
	   mcf.m_c_per_price,
	   c_f_count,
	   m_f_name,
	   m_f_count,
	   w_m_f_name,
	   w_m_count,
	   m_c_f_name,
	   m_c_count,
	   t_c_other
	   --into tarifes_table_for_return
	   FROM 
tarif t
join tarif_content tc 
on t.t_c_id_fk = tc.t_c_id 
join cassa_field cf 
on tc.t_c_cassa_id = cf.c_f_id 
join manager_field mf
on tc.t_c_manager_id = mf.m_f_id 
join web_manager_field wmf
on tc.t_c_web_id  = wmf.w_m_f_id 
join mobile_cassa_field mcf
on mcf.m_c_f_id  = tc.t_c_mobile_c_id where for_view =true order by t_month_price ;
--return tarifes_table_for_return;
end; 
$$;


ALTER FUNCTION public.get_tarifes_for_view() OWNER TO pcassa;

--
-- Name: verify_payment(uuid, uuid); Type: FUNCTION; Schema: public; Owner: pcassa
--

CREATE FUNCTION public.verify_payment(order_id_ uuid, tarif_id_ uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
declare 
state_checker bool;
count_row record;
t_c_id_ uuid;
m_c_f_id_ uuid;
m_f_id_ uuid;
w_m_f_id_ uuid;
c_f_id_ uuid;
tarif_id uuid;
begin
	select order_state  into state_checker from saved_order_and_tarif where order_id = order_id_;
    --raise notice '%', state_checker;
	if state_checker = TRUE then
		raise Exception 'error';
	end if;
	SELECT cass_stantion_count,
		   mobile_cass_count,
		   web_manager_count,
		   mobile_manager_count,
		   order_summ,
		   company_id,
		   date_part('day',order_ending -order_date) as sb_date
		   into count_row
	from saved_order_and_tarif soat where order_id = order_id_;
    INSERT INTO mobile_cassa_field(m_c_count) values(count_row.mobile_manager_count) returning m_c_f_id into m_c_f_id_;
    INSERT INTO manager_field (m_f_count) values(count_row.mobile_cass_count) returning m_f_id into m_f_id_;
    INSERT INTO web_manager_field  (w_m_count) values(count_row.web_manager_count) returning w_m_f_id into w_m_f_id_;
    INSERT INTO cassa_field  (c_f_count) values(count_row.cass_stantion_count) returning c_f_id into c_f_id_;
   --raise notice '%', c_f_id_;
    INSERT INTO tarif_content(t_c_cassa_id,
    t_c_other,
                              t_c_manager_id,
                              t_c_web_id,
                              t_c_mobile_c_id,
                              t_c_month)
    VALUES(c_f_id_,
    (select t_c_other from tarif_content tc where tc.t_c_id = (select t_c_id_fk from tarif where t_id = tarif_id_)),
           m_f_id_,
           w_m_f_id_,
           m_c_f_id_,
           count_row.sb_date
           ) RETURNING tarif_content.t_c_id into t_c_id_;
          --raise notice '%',t_c_id_;
    INSERT INTO tarif(t_month_price, t_c_id_fk, t_name) 
    values(count_row.order_summ,t_c_id_, 
   (select distinct t_name from tarif where t_id = tarif_id_))returning t_id into tarif_id;
    --INSERT INTO client_tarif(c_t_id, c_t_tarif_id, end_license) values(count_row.company_id, tarif_id, current_timestamp+concat(count_row.sb_date, ' days')::interval);
    --update saved_order_and_tarif set order_state = true where order_id = order_id_;
    update saved_order_and_tarif set tarif_id_fk  = tarif_id where order_id = order_id_;
end;
$$;


ALTER FUNCTION public.verify_payment(order_id_ uuid, tarif_id_ uuid) OWNER TO pcassa;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_table (
    admin_id integer NOT NULL,
    admin_name character varying,
    admin_login character varying NOT NULL,
    admin_password character varying NOT NULL,
    admin_privilege integer NOT NULL
);


ALTER TABLE public.admin_table OWNER TO postgres;

--
-- Name: admin_table_admin_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.admin_table ALTER COLUMN admin_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.admin_table_admin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bank_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_info (
    bank_id integer,
    country_code integer,
    return_url text,
    bank_login character varying(60),
    bank_password character varying(60),
    bank_token text,
    fail_url text,
    bank_lang character varying(40),
    register_url character varying,
    check_status_url character varying
);


ALTER TABLE public.bank_info OWNER TO postgres;

--
-- Name: cassa_field; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.cassa_field (
    c_f_id uuid DEFAULT gen_random_uuid() NOT NULL,
    c_per_price integer DEFAULT 1500 NOT NULL,
    c_inf_price integer DEFAULT 0 NOT NULL,
    c_f_name character varying[] DEFAULT ARRAY['Кассовая станция'::text, 'Cash stantion'::text],
    c_f_count integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.cassa_field OWNER TO pcassa;

--
-- Name: client_ip; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_ip (
    ip_id integer NOT NULL,
    ip_of_client text[] NOT NULL
);


ALTER TABLE public.client_ip OWNER TO postgres;

--
-- Name: client_ip_ip_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.client_ip ALTER COLUMN ip_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.client_ip_ip_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: client_tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_tarif (
    c_t_id uuid DEFAULT gen_random_uuid() NOT NULL,
    c_t_tarif_id uuid NOT NULL,
    start_license timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_license timestamp without time zone NOT NULL
);


ALTER TABLE public.client_tarif OWNER TO postgres;

--
-- Name: company; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.company (
    c_id uuid DEFAULT gen_random_uuid() NOT NULL,
    c_unique_id bigint NOT NULL,
    c_diller_id integer NOT NULL,
    c_pass text NOT NULL,
    c_name text NOT NULL,
    c_contact_name text NOT NULL,
    c_phone text NOT NULL,
    c_email text NOT NULL,
    c_inn text,
    c_kpp text,
    c_k_schet text,
    c_r_schet text,
    c_bik text,
    c_bank_name text,
    c_address text,
    c_verify_status character varying(10) DEFAULT false,
    c_token text
);


ALTER TABLE public.company OWNER TO pcassa;

--
-- Name: curr_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.curr_types (
    curr_id integer NOT NULL,
    curr_name character varying(40) NOT NULL
);


ALTER TABLE public.curr_types OWNER TO postgres;

--
-- Name: curr_types_curr_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.curr_types_curr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.curr_types_curr_id_seq OWNER TO postgres;

--
-- Name: curr_types_curr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.curr_types_curr_id_seq OWNED BY public.curr_types.curr_id;


--
-- Name: device_info; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_info (
    device_id integer NOT NULL,
    device_code text,
    device_license_key text
);


ALTER TABLE public.device_info OWNER TO postgres;

--
-- Name: device_info_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.device_info ALTER COLUMN device_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.device_info_device_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: device_port; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.device_port (
    port integer NOT NULL,
    unique_id_cp bigint,
    ip_of_client text[] NOT NULL
);


ALTER TABLE public.device_port OWNER TO postgres;

--
-- Name: device_port_port_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.device_port_port_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.device_port_port_seq OWNER TO postgres;

--
-- Name: device_port_port_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.device_port_port_seq OWNED BY public.device_port.port;


--
-- Name: diller; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.diller (
    d_id integer NOT NULL,
    d_pass text NOT NULL,
    d_name text NOT NULL,
    d_contact_name text NOT NULL,
    d_phone text NOT NULL,
    d_email text NOT NULL,
    d_inn text,
    d_kpp text,
    d_k_schet text,
    d_r_schet text,
    d_bik text,
    d_bank_name text,
    d_address text
);


ALTER TABLE public.diller OWNER TO pcassa;

--
-- Name: diller_d_id_seq; Type: SEQUENCE; Schema: public; Owner: pcassa
--

CREATE SEQUENCE public.diller_d_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.diller_d_id_seq OWNER TO pcassa;

--
-- Name: diller_d_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pcassa
--

ALTER SEQUENCE public.diller_d_id_seq OWNED BY public.diller.d_id;


--
-- Name: licenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.licenses (
    license_key text,
    product_id_fk integer,
    unique_id_cp bigint NOT NULL,
    column1 timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    own_ip text,
    own_port integer
);


ALTER TABLE public.licenses OWNER TO postgres;

--
-- Name: links; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.links (
    product_link text[],
    product_id integer NOT NULL
);


ALTER TABLE public.links OWNER TO postgres;

--
-- Name: manager_field; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.manager_field (
    m_f_id uuid DEFAULT gen_random_uuid() NOT NULL,
    m_per_price integer DEFAULT 500 NOT NULL,
    m_inf_price integer DEFAULT 0 NOT NULL,
    m_f_count integer,
    m_f_name character varying[] DEFAULT ARRAY['Мобильная касса'::text, 'Mobile cash'::text]
);


ALTER TABLE public.manager_field OWNER TO pcassa;

--
-- Name: mobile_cassa_field; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.mobile_cassa_field (
    m_c_f_id uuid DEFAULT gen_random_uuid() NOT NULL,
    m_c_f_name text[] DEFAULT ARRAY['Мобильный менеджер'::text, 'Mobile manager'::text] NOT NULL,
    m_c_per_price integer DEFAULT 1500 NOT NULL,
    m_c_inf_price integer DEFAULT 0 NOT NULL,
    m_c_count integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.mobile_cassa_field OWNER TO pcassa;

--
-- Name: order_tarif_email; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_tarif_email (
    t_id integer NOT NULL,
    t_c_name text NOT NULL,
    t_c_contact_name text NOT NULL,
    t_c_phone text NOT NULL,
    t_c_email text NOT NULL,
    t_c_inn text,
    t_c_address text NOT NULL,
    t_c_country character varying
);


ALTER TABLE public.order_tarif_email OWNER TO postgres;

--
-- Name: order_tarif_email_t_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.order_tarif_email ALTER COLUMN t_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.order_tarif_email_t_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permission_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permission_table (
    permission_id integer NOT NULL,
    permission_info character varying
);


ALTER TABLE public.permission_table OWNER TO postgres;

--
-- Name: privilege_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privilege_table (
    privilege_id integer NOT NULL,
    privilege_type integer NOT NULL
);


ALTER TABLE public.privilege_table OWNER TO postgres;

--
-- Name: saved_order_and_tarif; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.saved_order_and_tarif (
    order_id uuid DEFAULT gen_random_uuid() NOT NULL,
    order_summ numeric NOT NULL,
    cass_stantion_count integer NOT NULL,
    mobile_cass_count integer NOT NULL,
    mobile_manager_count integer NOT NULL,
    web_manager_count integer NOT NULL,
    company_id uuid NOT NULL,
    order_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    order_ending timestamp without time zone NOT NULL,
    order_state boolean DEFAULT false NOT NULL,
    order_curr_type integer DEFAULT 0 NOT NULL,
    tarif_id_fk uuid,
    for_view boolean DEFAULT true
);


ALTER TABLE public.saved_order_and_tarif OWNER TO pcassa;

--
-- Name: saved_order_and_tarif_bank; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.saved_order_and_tarif_bank (
    order_id integer NOT NULL,
    bank_order_id text,
    order_summ numeric NOT NULL,
    cass_stantion_count integer NOT NULL,
    mobile_cass_count integer NOT NULL,
    mobile_manager_count integer NOT NULL,
    web_manager_count integer NOT NULL,
    company_id integer NOT NULL,
    order_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    order_ending timestamp without time zone NOT NULL,
    order_state boolean DEFAULT false NOT NULL,
    order_curr_type integer DEFAULT 0 NOT NULL,
    tarif_id_fk integer,
    for_view boolean DEFAULT true,
    bank_state integer DEFAULT '-1'::integer
);


ALTER TABLE public.saved_order_and_tarif_bank OWNER TO postgres;

--
-- Name: saved_order_and_tarif_bank_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.saved_order_and_tarif_bank_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.saved_order_and_tarif_bank_order_id_seq OWNER TO postgres;

--
-- Name: saved_order_and_tarif_bank_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.saved_order_and_tarif_bank_order_id_seq OWNED BY public.saved_order_and_tarif_bank.order_id;


--
-- Name: tarif; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.tarif (
    t_id uuid DEFAULT gen_random_uuid() NOT NULL,
    t_month_price integer NOT NULL,
    t_inf_price integer DEFAULT 0,
    t_c_id_fk uuid,
    t_name character varying[] DEFAULT ARRAY['Свой тариф'::character varying, 'Self tarif'::character varying],
    for_view boolean DEFAULT false
);


ALTER TABLE public.tarif OWNER TO pcassa;

--
-- Name: tarif_content; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.tarif_content (
    t_c_id uuid DEFAULT gen_random_uuid() NOT NULL,
    t_c_cassa_id uuid NOT NULL,
    t_c_manager_id uuid NOT NULL,
    t_c_web_id uuid NOT NULL,
    t_c_other text[],
    t_c_mobile_c_id uuid,
    t_c_month integer DEFAULT 30 NOT NULL
);


ALTER TABLE public.tarif_content OWNER TO pcassa;

--
-- Name: temp_company; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.temp_company (
    t_id uuid DEFAULT gen_random_uuid() NOT NULL,
    t_c_pass text NOT NULL,
    t_c_name text NOT NULL,
    t_c_contact_name text NOT NULL,
    t_c_phone text NOT NULL,
    t_c_email text NOT NULL,
    t_c_verify_link text NOT NULL,
    t_c_inn text,
    t_c_kpp text,
    t_c_k_schet text,
    t_c_r_schet text,
    t_c_bik text,
    t_c_bank_name text,
    t_c_address text NOT NULL,
    t_c_country character varying DEFAULT 1 NOT NULL
);


ALTER TABLE public.temp_company OWNER TO pcassa;

--
-- Name: uniqunes_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uniqunes_product (
    device_code text NOT NULL,
    product_id integer NOT NULL,
    u_license_key text
);


ALTER TABLE public.uniqunes_product OWNER TO postgres;

--
-- Name: web_manager_field; Type: TABLE; Schema: public; Owner: pcassa
--

CREATE TABLE public.web_manager_field (
    w_m_f_id uuid DEFAULT gen_random_uuid() NOT NULL,
    w_m_f_name text[] DEFAULT ARRAY['Веб менеджер'::text, 'Web manager'::text] NOT NULL,
    w_m_per_price integer DEFAULT 1500 NOT NULL,
    w_m_inf_price integer DEFAULT 0 NOT NULL,
    w_m_count integer NOT NULL
);


ALTER TABLE public.web_manager_field OWNER TO pcassa;

--
-- Name: curr_types curr_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curr_types ALTER COLUMN curr_id SET DEFAULT nextval('public.curr_types_curr_id_seq'::regclass);


--
-- Name: device_port port; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_port ALTER COLUMN port SET DEFAULT nextval('public.device_port_port_seq'::regclass);


--
-- Name: diller d_id; Type: DEFAULT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.diller ALTER COLUMN d_id SET DEFAULT nextval('public.diller_d_id_seq'::regclass);


--
-- Name: saved_order_and_tarif_bank order_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_order_and_tarif_bank ALTER COLUMN order_id SET DEFAULT nextval('public.saved_order_and_tarif_bank_order_id_seq'::regclass);


--
-- Data for Name: admin_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_table (admin_id, admin_name, admin_login, admin_password, admin_privilege) FROM stdin;
\.
COPY public.admin_table (admin_id, admin_name, admin_login, admin_password, admin_privilege) FROM '$$PATH$$/3265.dat';

--
-- Data for Name: bank_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_info (bank_id, country_code, return_url, bank_login, bank_password, bank_token, fail_url, bank_lang, register_url, check_status_url) FROM stdin;
\.
COPY public.bank_info (bank_id, country_code, return_url, bank_login, bank_password, bank_token, fail_url, bank_lang, register_url, check_status_url) FROM '$$PATH$$/3267.dat';

--
-- Data for Name: cassa_field; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.cassa_field (c_f_id, c_per_price, c_inf_price, c_f_name, c_f_count) FROM stdin;
\.
COPY public.cassa_field (c_f_id, c_per_price, c_inf_price, c_f_name, c_f_count) FROM '$$PATH$$/3254.dat';

--
-- Data for Name: client_ip; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_ip (ip_id, ip_of_client) FROM stdin;
\.
COPY public.client_ip (ip_id, ip_of_client) FROM '$$PATH$$/3268.dat';

--
-- Data for Name: client_tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_tarif (c_t_id, c_t_tarif_id, start_license, end_license) FROM stdin;
\.
COPY public.client_tarif (c_t_id, c_t_tarif_id, start_license, end_license) FROM '$$PATH$$/3262.dat';

--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.company (c_id, c_unique_id, c_diller_id, c_pass, c_name, c_contact_name, c_phone, c_email, c_inn, c_kpp, c_k_schet, c_r_schet, c_bik, c_bank_name, c_address, c_verify_status, c_token) FROM stdin;
\.
COPY public.company (c_id, c_unique_id, c_diller_id, c_pass, c_name, c_contact_name, c_phone, c_email, c_inn, c_kpp, c_k_schet, c_r_schet, c_bik, c_bank_name, c_address, c_verify_status, c_token) FROM '$$PATH$$/3260.dat';

--
-- Data for Name: curr_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.curr_types (curr_id, curr_name) FROM stdin;
\.
COPY public.curr_types (curr_id, curr_name) FROM '$$PATH$$/3276.dat';

--
-- Data for Name: device_info; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_info (device_id, device_code, device_license_key) FROM stdin;
\.
COPY public.device_info (device_id, device_code, device_license_key) FROM '$$PATH$$/3278.dat';

--
-- Data for Name: device_port; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.device_port (port, unique_id_cp, ip_of_client) FROM stdin;
\.
COPY public.device_port (port, unique_id_cp, ip_of_client) FROM '$$PATH$$/3280.dat';

--
-- Data for Name: diller; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.diller (d_id, d_pass, d_name, d_contact_name, d_phone, d_email, d_inn, d_kpp, d_k_schet, d_r_schet, d_bik, d_bank_name, d_address) FROM stdin;
\.
COPY public.diller (d_id, d_pass, d_name, d_contact_name, d_phone, d_email, d_inn, d_kpp, d_k_schet, d_r_schet, d_bik, d_bank_name, d_address) FROM '$$PATH$$/3259.dat';

--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.licenses (license_key, product_id_fk, unique_id_cp, column1, own_ip, own_port) FROM stdin;
\.
COPY public.licenses (license_key, product_id_fk, unique_id_cp, column1, own_ip, own_port) FROM '$$PATH$$/3282.dat';

--
-- Data for Name: links; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.links (product_link, product_id) FROM stdin;
\.
COPY public.links (product_link, product_id) FROM '$$PATH$$/3264.dat';

--
-- Data for Name: manager_field; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.manager_field (m_f_id, m_per_price, m_inf_price, m_f_count, m_f_name) FROM stdin;
\.
COPY public.manager_field (m_f_id, m_per_price, m_inf_price, m_f_count, m_f_name) FROM '$$PATH$$/3255.dat';

--
-- Data for Name: mobile_cassa_field; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.mobile_cassa_field (m_c_f_id, m_c_f_name, m_c_per_price, m_c_inf_price, m_c_count) FROM stdin;
\.
COPY public.mobile_cassa_field (m_c_f_id, m_c_f_name, m_c_per_price, m_c_inf_price, m_c_count) FROM '$$PATH$$/3253.dat';

--
-- Data for Name: order_tarif_email; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_tarif_email (t_id, t_c_name, t_c_contact_name, t_c_phone, t_c_email, t_c_inn, t_c_address, t_c_country) FROM stdin;
\.
COPY public.order_tarif_email (t_id, t_c_name, t_c_contact_name, t_c_phone, t_c_email, t_c_inn, t_c_address, t_c_country) FROM '$$PATH$$/3270.dat';

--
-- Data for Name: permission_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permission_table (permission_id, permission_info) FROM stdin;
\.
COPY public.permission_table (permission_id, permission_info) FROM '$$PATH$$/3272.dat';

--
-- Data for Name: privilege_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.privilege_table (privilege_id, privilege_type) FROM stdin;
\.
COPY public.privilege_table (privilege_id, privilege_type) FROM '$$PATH$$/3273.dat';

--
-- Data for Name: saved_order_and_tarif; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.saved_order_and_tarif (order_id, order_summ, cass_stantion_count, mobile_cass_count, mobile_manager_count, web_manager_count, company_id, order_date, order_ending, order_state, order_curr_type, tarif_id_fk, for_view) FROM stdin;
\.
COPY public.saved_order_and_tarif (order_id, order_summ, cass_stantion_count, mobile_cass_count, mobile_manager_count, web_manager_count, company_id, order_date, order_ending, order_state, order_curr_type, tarif_id_fk, for_view) FROM '$$PATH$$/3261.dat';

--
-- Data for Name: saved_order_and_tarif_bank; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.saved_order_and_tarif_bank (order_id, bank_order_id, order_summ, cass_stantion_count, mobile_cass_count, mobile_manager_count, web_manager_count, company_id, order_date, order_ending, order_state, order_curr_type, tarif_id_fk, for_view, bank_state) FROM stdin;
\.
COPY public.saved_order_and_tarif_bank (order_id, bank_order_id, order_summ, cass_stantion_count, mobile_cass_count, mobile_manager_count, web_manager_count, company_id, order_date, order_ending, order_state, order_curr_type, tarif_id_fk, for_view, bank_state) FROM '$$PATH$$/3274.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.tarif (t_id, t_month_price, t_inf_price, t_c_id_fk, t_name, for_view) FROM stdin;
\.
COPY public.tarif (t_id, t_month_price, t_inf_price, t_c_id_fk, t_name, for_view) FROM '$$PATH$$/3257.dat';

--
-- Data for Name: tarif_content; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.tarif_content (t_c_id, t_c_cassa_id, t_c_manager_id, t_c_web_id, t_c_other, t_c_mobile_c_id, t_c_month) FROM stdin;
\.
COPY public.tarif_content (t_c_id, t_c_cassa_id, t_c_manager_id, t_c_web_id, t_c_other, t_c_mobile_c_id, t_c_month) FROM '$$PATH$$/3256.dat';

--
-- Data for Name: temp_company; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.temp_company (t_id, t_c_pass, t_c_name, t_c_contact_name, t_c_phone, t_c_email, t_c_verify_link, t_c_inn, t_c_kpp, t_c_k_schet, t_c_r_schet, t_c_bik, t_c_bank_name, t_c_address, t_c_country) FROM stdin;
\.
COPY public.temp_company (t_id, t_c_pass, t_c_name, t_c_contact_name, t_c_phone, t_c_email, t_c_verify_link, t_c_inn, t_c_kpp, t_c_k_schet, t_c_r_schet, t_c_bik, t_c_bank_name, t_c_address, t_c_country) FROM '$$PATH$$/3263.dat';

--
-- Data for Name: uniqunes_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uniqunes_product (device_code, product_id, u_license_key) FROM stdin;
\.
COPY public.uniqunes_product (device_code, product_id, u_license_key) FROM '$$PATH$$/3283.dat';

--
-- Data for Name: web_manager_field; Type: TABLE DATA; Schema: public; Owner: pcassa
--

COPY public.web_manager_field (w_m_f_id, w_m_f_name, w_m_per_price, w_m_inf_price, w_m_count) FROM stdin;
\.
COPY public.web_manager_field (w_m_f_id, w_m_f_name, w_m_per_price, w_m_inf_price, w_m_count) FROM '$$PATH$$/3252.dat';

--
-- Name: admin_table_admin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_table_admin_id_seq', 1, true);


--
-- Name: client_ip_ip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.client_ip_ip_id_seq', 1, true);


--
-- Name: curr_types_curr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.curr_types_curr_id_seq', 1, false);


--
-- Name: device_info_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_info_device_id_seq', 177, true);


--
-- Name: device_port_port_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.device_port_port_seq', 4056, true);


--
-- Name: diller_d_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pcassa
--

SELECT pg_catalog.setval('public.diller_d_id_seq', 1, true);


--
-- Name: order_tarif_email_t_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_tarif_email_t_id_seq', 30, true);


--
-- Name: saved_order_and_tarif_bank_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.saved_order_and_tarif_bank_order_id_seq', 26, true);


--
-- Name: admin_table admin_table_admin_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_table
    ADD CONSTRAINT admin_table_admin_login_key UNIQUE (admin_login);


--
-- Name: admin_table admin_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_table
    ADD CONSTRAINT admin_table_pkey PRIMARY KEY (admin_id);


--
-- Name: cassa_field cassa_field_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.cassa_field
    ADD CONSTRAINT cassa_field_pkey PRIMARY KEY (c_f_id);


--
-- Name: client_ip client_ip_ip_of_client_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_ip
    ADD CONSTRAINT client_ip_ip_of_client_key UNIQUE (ip_of_client);


--
-- Name: client_ip client_ip_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_ip
    ADD CONSTRAINT client_ip_pkey PRIMARY KEY (ip_id);


--
-- Name: client_tarif client_tarif_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_tarif
    ADD CONSTRAINT client_tarif_pk PRIMARY KEY (c_t_id, c_t_tarif_id);


--
-- Name: company company_pk_; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_pk_ UNIQUE (c_name, c_phone, c_email);


--
-- Name: company company_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_pkey PRIMARY KEY (c_id);


--
-- Name: company company_un; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_un UNIQUE (c_unique_id);


--
-- Name: curr_types curr_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curr_types
    ADD CONSTRAINT curr_types_pkey PRIMARY KEY (curr_id);


--
-- Name: device_info device_info_device_license_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_info
    ADD CONSTRAINT device_info_device_license_key_key UNIQUE (device_license_key);


--
-- Name: device_info device_info_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_info
    ADD CONSTRAINT device_info_pkey PRIMARY KEY (device_id);


--
-- Name: device_port device_port_port_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_port
    ADD CONSTRAINT device_port_port_key UNIQUE (port);


--
-- Name: device_port device_port_unique_id_cp_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_port
    ADD CONSTRAINT device_port_unique_id_cp_key UNIQUE (unique_id_cp);


--
-- Name: diller diller_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.diller
    ADD CONSTRAINT diller_pkey PRIMARY KEY (d_id);


--
-- Name: licenses licenses_license_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_license_key_key UNIQUE (license_key);


--
-- Name: links links_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.links
    ADD CONSTRAINT links_un UNIQUE (product_id);


--
-- Name: manager_field manager_field_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.manager_field
    ADD CONSTRAINT manager_field_pkey PRIMARY KEY (m_f_id);


--
-- Name: mobile_cassa_field mobile_cassa_field_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.mobile_cassa_field
    ADD CONSTRAINT mobile_cassa_field_pkey PRIMARY KEY (m_c_f_id);


--
-- Name: permission_table permission_table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permission_table
    ADD CONSTRAINT permission_table_pkey PRIMARY KEY (permission_id);


--
-- Name: saved_order_and_tarif_bank saved_order_and_tarif_bank_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.saved_order_and_tarif_bank
    ADD CONSTRAINT saved_order_and_tarif_bank_pkey PRIMARY KEY (order_id);


--
-- Name: saved_order_and_tarif saved_order_and_tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.saved_order_and_tarif
    ADD CONSTRAINT saved_order_and_tarif_pkey PRIMARY KEY (order_id);


--
-- Name: tarif_content tarif_content_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_pkey PRIMARY KEY (t_c_id);


--
-- Name: tarif_content tarif_content_t_c_cassa_id_key; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_t_c_cassa_id_key UNIQUE (t_c_cassa_id);


--
-- Name: tarif_content tarif_content_t_c_manager_id_key; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_t_c_manager_id_key UNIQUE (t_c_manager_id);


--
-- Name: tarif_content tarif_content_t_c_sklad_id_key; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_t_c_sklad_id_key UNIQUE (t_c_web_id);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (t_id);


--
-- Name: tarif tarif_t_c_id_fk_key; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif
    ADD CONSTRAINT tarif_t_c_id_fk_key UNIQUE (t_c_id_fk);


--
-- Name: temp_company temp_company_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.temp_company
    ADD CONSTRAINT temp_company_pkey PRIMARY KEY (t_id);


--
-- Name: diller unique_d_pass; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.diller
    ADD CONSTRAINT unique_d_pass UNIQUE (d_pass);


--
-- Name: uniqunes_product uniqunes_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uniqunes_product
    ADD CONSTRAINT uniqunes_product_pkey PRIMARY KEY (device_code, product_id);


--
-- Name: uniqunes_product uniqunes_product_un; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uniqunes_product
    ADD CONSTRAINT uniqunes_product_un UNIQUE (u_license_key);


--
-- Name: web_manager_field web_manager_field_pkey; Type: CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.web_manager_field
    ADD CONSTRAINT web_manager_field_pkey PRIMARY KEY (w_m_f_id);


--
-- Name: saved_order_and_tarif delete_after_saved; Type: TRIGGER; Schema: public; Owner: pcassa
--

CREATE TRIGGER delete_after_saved AFTER DELETE ON public.saved_order_and_tarif FOR EACH ROW EXECUTE FUNCTION public.delete_from_parent();


--
-- Name: client_tarif client_tarif_c_t_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_tarif
    ADD CONSTRAINT client_tarif_c_t_id_fkey FOREIGN KEY (c_t_id) REFERENCES public.company(c_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: client_tarif client_tarif_c_t_tarif_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_tarif
    ADD CONSTRAINT client_tarif_c_t_tarif_id_fkey FOREIGN KEY (c_t_tarif_id) REFERENCES public.tarif(t_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: device_info device_info_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_info
    ADD CONSTRAINT device_info_fk FOREIGN KEY (device_license_key) REFERENCES public.uniqunes_product(u_license_key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: device_port device_port_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.device_port
    ADD CONSTRAINT device_port_fk FOREIGN KEY (unique_id_cp) REFERENCES public.company(c_unique_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: company fk_c_diller_id; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT fk_c_diller_id FOREIGN KEY (c_diller_id) REFERENCES public.diller(d_id);


--
-- Name: licenses licenses_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_fk FOREIGN KEY (license_key) REFERENCES public.uniqunes_product(u_license_key) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: licenses licenses_fk_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_fk_ FOREIGN KEY (unique_id_cp) REFERENCES public.company(c_unique_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: privilege_table privilege_table_privilege_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilege_table
    ADD CONSTRAINT privilege_table_privilege_type_fkey FOREIGN KEY (privilege_type) REFERENCES public.permission_table(permission_id);


--
-- Name: saved_order_and_tarif saved_order_and_tarif_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.saved_order_and_tarif
    ADD CONSTRAINT saved_order_and_tarif_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.company(c_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: saved_order_and_tarif saved_order_and_tarif_fk; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.saved_order_and_tarif
    ADD CONSTRAINT saved_order_and_tarif_fk FOREIGN KEY (order_curr_type) REFERENCES public.curr_types(curr_id);


--
-- Name: tarif_content tarif_content_fk; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_fk FOREIGN KEY (t_c_mobile_c_id) REFERENCES public.mobile_cassa_field(m_c_f_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tarif_content tarif_content_fk_web; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_fk_web FOREIGN KEY (t_c_web_id) REFERENCES public.web_manager_field(w_m_f_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tarif_content tarif_content_t_c_cassa_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_t_c_cassa_id_fkey FOREIGN KEY (t_c_cassa_id) REFERENCES public.cassa_field(c_f_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tarif_content tarif_content_t_c_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif_content
    ADD CONSTRAINT tarif_content_t_c_manager_id_fkey FOREIGN KEY (t_c_manager_id) REFERENCES public.manager_field(m_f_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tarif tarif_fk; Type: FK CONSTRAINT; Schema: public; Owner: pcassa
--

ALTER TABLE ONLY public.tarif
    ADD CONSTRAINT tarif_fk FOREIGN KEY (t_c_id_fk) REFERENCES public.tarif_content(t_c_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

