from api.api_creator import run_server


if __name__ == '__main__':
    run_server()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
