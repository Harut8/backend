import uuid
from abc import abstractmethod, ABCMeta
from typing import Union
from asyncpg import Record

class LicenseDbInterface(metaclass=ABCMeta):
    ...


