from abc import ABCMeta


class LicenseServiceInterface(metaclass=ABCMeta):
    ...
