import os
import smtplib,ssl
import urllib
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders
from email.utils import formataddr
from amqp_service.celery_app.celery_app import celery_decor


#@celery_decor.task
def send_excel_mail(send_to,order_id,subject='DOWNLOAD EXCEL',text='DOWNLOAD EXCEL',isTls=True):
    try:
        from service.parser import ParseEnv
        sender_email = ParseEnv.EMAIL_
        password = ParseEnv.EMAIL_PASS
        smtp_server = smtplib.SMTP("mail.pcassa.ru", 587)
        smtp_server.starttls()  # setting up to TLS connection
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = formataddr(("PCASSA MANAGER", sender_email))
        msg['Date'] = formatdate(localtime = True)
        f = f"service/csv/{order_id}.xlsx"
        attachment = open(f, "rb")
        file_name = os.path.basename(f)
        msg.attach(MIMEText(text))
        part = MIMEApplication(attachment.read(), _subtype='xlsx')
        encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment', filename=file_name)
        msg.attach(part)
        if isTls:
            smtp_server.login(sender_email,password)
            smtp_server.sendmail(sender_email, send_to, msg.as_string())
            smtp_server.quit()
            print("EXCEL SENDED")
        return True
    except Exception as e:
        print(e)
        return
