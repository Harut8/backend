import uuid
from typing import Union
from mailing.excel_mailing.send_excel import send_excel_mail
from fastapi import APIRouter, Depends, HTTPException, Header
from fastapi import BackgroundTasks
from fastapi.responses import RedirectResponse
from starlette import status
from mailing.zayavka_mailing.send_zayavka_company import send_zayavka_company_email_
from mailing.zayavka_mailing.send_zayavka_partner import send_zayavka_partner_email_
from auth.auth import auth_required
from models.order_model.order_model import BuyTariff, PartnerZayavka, CompanyZayavka
from service.excel_manager.excel_rewriter import ExcelAnketaRewriter
from service.order_service_manager.order_service_manager import OrderServiceManager


def send_zayavka_company_email(receiver, message):
    send_zayavka_company_email_(receiver, message)


def send_zayavka_partner_email(message):
    send_zayavka_partner_email_(message)


async def excel_creator(order_id):
    info_1 = await OrderServiceManager.get_info_for_excel(order_id)
    info_2 = await OrderServiceManager.get_tarifes_for_personal_crateing(language='ru')
    if info_1 and info_2 is not None:
        if ExcelAnketaRewriter.set_all_attributes(info_1, info_2):
            send_excel_mail(info_1.c_email, order_id)
    raise Exception("EXCEL ERROR")


order_router = APIRouter(tags=["ORDER API"], prefix="/order")


@order_router.get('/ping')
async def order_ping():
    return {"status": "ORDER PINGING"}


@order_router.get("/verify-order")
async def _verify_order(order_token: Union[str, uuid.UUID]):
    _state = await OrderServiceManager.verify_order(order_token)
    if not _state:
        return HTTPException(400)
    return RedirectResponse("https://pcassa.ru")


@order_router.get("/verify-payment")
async def verify_payment(orderId: Union[str, uuid.UUID], lang: str, order_id: Union[str, uuid.UUID]):
    _pay_state = await OrderServiceManager.check_payment_state(orderId, order_id)
    if isinstance(_pay_state, bool):
        return RedirectResponse("http://owa.pcassa.ru:5002/Bankok")
    return RedirectResponse("http://owa.pcassa.ru:5002/Failed")


@order_router.post("/buy-by-card")
@auth_required
async def buy_by_card(tariff_body: BuyTariff, authorize=Header(None)):
    print(authorize)
    from auth.auth import decode_token
    c_uuid = await decode_token(authorize)
    c_uuid = c_uuid.sub
    _bank_order_state = await OrderServiceManager.buy_by_card(tariff_body, c_uuid)
    if _bank_order_state == -1:
        return HTTPException(400, 'WRONG COUNTRY PAYMENT SYSTEM')
    if isinstance(_bank_order_state, dict):
        return HTTPException(400, _bank_order_state)
    print(_bank_order_state)
    if _bank_order_state:
        x = _bank_order_state
        return x
        # return RedirectResponse(x, status_code=status.HTTP_303_SEE_OTHER, headers={'Access-Control-Allow-Origin':'*'})
        # return _bank_order_state
    return HTTPException(400)


@order_router.post("/buy-by-transfer")
@auth_required
async def buy_by_transfer(tariff_body: BuyTariff, excel_creator_back: BackgroundTasks, authorize=Header(None)):
    from auth.auth import decode_token
    c_uuid = await decode_token(authorize)
    c_uuid = c_uuid.sub
    _order_id = await OrderServiceManager.post_transfer_tarif(tariff_body, c_uuid)
    print(_order_id)
    if _order_id:
        excel_creator_back.add_task(excel_creator, _order_id)
        # excel_creator_back.add_task(excel_sender, state_of_buy["order_id"] )
        return {"status": "ok"}
    return HTTPException(400)


@order_router.post("/renew-order/{order_id}")
@auth_required
async def renew_order(order_id: Union[str, uuid.UUID], authorize=Header(None)):
    from auth.auth import decode_token
    c_uuid = await decode_token(authorize)
    c_uuid = c_uuid.sub
    return await OrderServiceManager.renew_order_info(order_id)


@order_router.post('/order-email-company')
async def order_email(order_model: CompanyZayavka, back_task: BackgroundTasks):
    back_task.add_task(send_zayavka_company_email_, order_model.acc_email, order_model)
    return {"status": "success"}


@order_router.post("/order-email-partner")
async def zayavka_company(partner_zayavka: PartnerZayavka, back_task: BackgroundTasks):
    print(partner_zayavka)
    back_task.add_task(send_zayavka_partner_email_, partner_zayavka)
    return {"status": "success"}
