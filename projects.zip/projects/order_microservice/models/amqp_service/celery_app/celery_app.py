import asyncio

from celery import Celery
from celery.schedules import crontab
from service.parser import ParseEnv

ParseEnv()


celery_decor: Celery = Celery(
    'celery_app',
    #broker='amqp://'+ParseEnv.RABBIT_USER + ':'+ParseEnv.RABBIT_PASS+'@localhost:5672/pcassa_order',
    broker='redis://redis:6379/3',
    backend='redis://redis:6379/3',
    include=[
        'mailing.verify_mailing.send_order_verify_link',
        'mailing.download_mailing.send_download_links',
        'mailing.excel_mailing.send_excel',
        'repository.order_db_manager.order_db_manager'])


