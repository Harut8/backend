from num2words import num2words
import dataclasses
from openpyxl import load_workbook
import datetime
from models.tariff_model.tariff_model import TariffModelForExcel, InnerModelForTarif


@dataclasses.dataclass
class ExcelAnketaRewriter:

    buyer: str = "ООО «{org_name}» ИНН {inn_num}, {address}"
    cheque_num: str = "№ {cheque_num}"
    cheque_datetime: str = "от {day} {month} {year} г."
    buyed_tarifes_and_summ: str = "{tarif_count}, на сумму {tarif_summ}"
    tarife_summ: str = "{tarif_summ}"
    summ_with_words: str = ""
    MonthDictRu = {'1': 'Январь',
                   '2': 'Февраль',
                   '3': 'Март',
                   '4': 'Апрель',
                   '5': 'Май',
                   '6': 'Июнь',
                   '7': 'Июль',
                   '8': 'Август',
                   '9': 'Сентябрь',
                   '10': 'Октябрь',
                   '11': 'Ноябрь',
                   '12': 'Декабрь'}

    @classmethod
    def set_buyer_info(cls, org_name=None, inn_num=None, address=None):
        if org_name and inn_num and address is not None:
            cls.buyer = cls.buyer.format(org_name=org_name, address=address, inn_num=inn_num)
        else:
            raise Exception("ERROR")

    @classmethod
    def set_order_info(cls, cheque_num=None, tarif_count=None, tarif_summ=None):
        try:

            #tarif_summ = tarif_summ.replace('$','')
            print(cheque_num, tarif_summ, tarif_count)
            if cheque_num and tarif_summ and tarif_count is not None:
                cls.cheque_num = cls.cheque_num.format(cheque_num=cheque_num)
                cls.tarife_summ = cls.tarife_summ.format(tarif_summ=tarif_summ)
                cls.buyed_tarifes_and_summ = cls.buyed_tarifes_and_summ.format(tarif_count=tarif_count, tarif_summ=tarif_summ)
                cls.summ_with_words = num2words(int(float(tarif_summ)),lang="ru")
                print(cls.summ_with_words)
            else:
                raise Exception("VALUE ERROR")
        except Exception as e:
            print(e)
            raise Exception("VALUE ERROR")

    @classmethod
    def set_datetime(cls):
        try:
            now__ = datetime.datetime.utcnow()
            cls.cheque_datetime = cls.cheque_datetime.format(
                month=cls.MonthDictRu[str(now__.month)],
                day=now__.day,
                year=now__.year)
            print(1)
        except Exception as e:
            raise Exception(e)

    @classmethod
    def rewrite_excel(cls, order_id, tarif_info: TariffModelForExcel, personal_prices: InnerModelForTarif):
        try:
            import os
            print(os.getcwd())
            workbook = load_workbook(filename="service/csv/schet.xlsx")
            # open workbook
            sheet = workbook.active


            # modify the desired cell
            sheet["B8"] = cls.cheque_num
            sheet["C8"] = cls.cheque_datetime
            sheet["B11"] = cls.buyer
            sheet["B18"] = cls.tarife_summ
            sheet["C17"] = cls.buyed_tarifes_and_summ
            sheet["A20"] = cls.summ_with_words
            sheet["D13"] = tarif_info.csc
            sheet["D14"] = tarif_info.mcc
            sheet["D15"] = tarif_info.wmc
            sheet["D16"] = tarif_info.mmc
            sheet["G13"] = int(personal_prices.cassa_prices) or 0
            sheet["G14"] = int(personal_prices.mobile_prices) or 0
            sheet["G15"] = int(personal_prices.web_prices) or 0
            sheet["G16"] = int(personal_prices.manager_prices) or 0
            sheet["H13"] = (personal_prices.cassa_prices or 0)*tarif_info.csc
            sheet["H14"] = (personal_prices.mobile_prices or 0)*tarif_info.mcc
            sheet["H15"] = (personal_prices.web_prices or 0)*tarif_info.wmc
            sheet["H16"] = (personal_prices.manager_prices or 0)*tarif_info.mmc
            workbook.save(filename=f"service/csv/{order_id}.xlsx")
            print("CREATED EXCEL")
            return True
        except Exception as e:
            print(e)
            return None

    @classmethod
    def set_all_attributes(cls, info: TariffModelForExcel, info2: InnerModelForTarif):
        try:
            cls.set_datetime()
            cls.set_buyer_info(info.c_name,info.c_inn,info.c_address)
            cls.set_order_info(info.order_id,info.count,info.order_summ)
            cls.rewrite_excel(info.order_id, tarif_info=info, personal_prices=info2)
            return True
        except Exception as e:
            print(e)
            return None

