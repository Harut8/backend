from abc import abstractmethod, ABCMeta
from typing import Union
from models.user_model.user_model import UserInfo, UserRegistration


class OrderServiceInterface(metaclass=ABCMeta):
    ...
