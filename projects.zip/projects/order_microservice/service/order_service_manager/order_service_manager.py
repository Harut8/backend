import asyncio
import json
import uuid
from typing import Union

import httpx

from repository.order_db_manager.order_db_manager import OrderDbManager
from models.order_model.order_model import BuyTariff, ReNewTariff
from models.tariff_model.tariff_model import TariffModelForExcel, InnerModelForTarif
from service.order_service_manager.order_service_interface import OrderServiceInterface


language_dict = {
            "ru": 0,
            "en": 1,
            "hy": 2
        }


class OrderServiceManager(OrderServiceInterface):

    @staticmethod
    async def card_buying_logic(tariff_body: ReNewTariff | BuyTariff, company_id, renew=False):
        if not renew:
            # create order
            _temp_order_id = await OrderServiceManager.add_order_to_temp(tariff_body, company_id)
            # get bank url
            _bank_url = await OrderServiceManager.get_request_url(_temp_order_id["order_id"], None)
            _path = _bank_url + "order_id="
        else:
            _temp_order_id = await OrderServiceManager.add_order_to_temp_for_renew(tariff_body, company_id)
            _bank_url = await OrderServiceManager.get_request_url(_temp_order_id["order_id"], tariff_body.order_id)
            _path = _bank_url + "?order_id="
        if not _bank_url:
            return -1  # something wrong
        _bank_url = _path + str(_temp_order_id["order_id"])
        # redirect url
        _form_url = await OrderServiceManager.request_to_bank(_bank_url)
        print(_form_url)
        return _form_url
    @staticmethod
    async def buy_by_card(tariff_body: BuyTariff, company_id):
        try:
            _form_url = await OrderServiceManager.card_buying_logic(tariff_body, company_id)
            return _form_url
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def renew_by_card(tariff_body: ReNewTariff, company_id):
        try:
            _form_url = await OrderServiceManager.card_buying_logic(tariff_body, company_id, renew=True)
            return _form_url
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def post_transfer_tarif(item: BuyTariff, company_id):
        try:
            _order_id = await OrderDbManager.add_order_for_tariff(item, company_id)
            if _order_id:
                return _order_id['order_id']
            return
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def renew_transfer_tariff(item: ReNewTariff, company_id):
        try:
            _order_id = await OrderDbManager.update_order_for_transfer_renew(item, company_id)
            if _order_id:
                return _order_id
            return
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def get_info_for_excel(order_id):
        try:
            info_ = await OrderDbManager.get_info_for_excel(order_id)
            if info_ is not None:
                return TariffModelForExcel(
                    order_id=info_['order_id'],
                    c_email=info_['c_email'],
                    c_name=info_['c_name'],
                    c_inn=info_['c_inn'],
                    c_address=info_['c_address'],
                    order_summ=info_['order_summ'],
                    count=info_['count'],
                    csc=info_['csc'],
                    mcc=info_['mcc'],
                    mmc=info_['mmc'],
                    wmc=info_['wmc'],
                )
            return
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def get_tarifes_for_personal_crateing(language):
        try:
            temp_ = await OrderDbManager.get_tarifes_for_personal()
            # print(temp_)
            lan_ = language_dict[language]
            if temp_ is None:
                return
            else:
                # return temp_
                return InnerModelForTarif(
                    cassa_names=temp_[3]["c_f_name"][lan_],
                    cassa_prices=temp_[3]["c_per_price"],
                    manager_names=temp_[0]["c_f_name"][lan_],
                    manager_prices=temp_[0]["c_per_price"],
                    web_names=temp_[1]["c_f_name"][lan_],
                    web_prices=temp_[1]["c_per_price"],
                    mobile_cassa_names=temp_[2]["c_f_name"][lan_],
                    mobile_prices=temp_[2]["c_per_price"],
                )
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def add_order_to_temp(tariff_body: BuyTariff, company_id):
        try:
            _temp_order_id = await OrderDbManager.add_order_to_temp(tariff_body, company_id)
            if not _temp_order_id:
                return
            return _temp_order_id
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def add_order_to_temp_for_renew(tariff_body: ReNewTariff, company_id):
        try:
            _temp_order_id = await OrderDbManager.add_order_to_temp_for_renew(tariff_body, company_id)
            if not _temp_order_id:
                return
            return _temp_order_id
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def get_request_url(temp_order_id: Union[str, uuid.UUID], order_id):
        try:
            _request_url = await OrderDbManager.get_request_url(temp_order_id, order_id)
            if not _request_url:
                return
            return _request_url["get_alpha_bank_url"]
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def add_bank_order_to_temp(bank_order_id: Union[str, uuid.UUID], order_id: Union[str, uuid.UUID]):
        try:
            _bank_order_id = await OrderDbManager.add_bank_order_to_temp(bank_order_id, order_id)
            if not _bank_order_id:
                return
            return _bank_order_id
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def request_to_bank(bank_url):
        try:
            async with httpx.AsyncClient() as client:
                _form_state = await client.post(bank_url)
                _form_state = _form_state.json()
                _form_error = _form_state.get("errorCode", None)
                _form_error_message = _form_state.get("errorMessage", None)
                _form_url = _form_state.get("formUrl", None)
                if _form_url and not _form_error:
                    return _form_url
                return _form_error_message
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def check_payment_state(bank_order_id: Union[str, uuid.UUID], order_id, old_order_id=None, renew=False):
        try:
            from amqp_service.rabbit_app.pika_app import RabbitMQ
            bank_and_order = {'bank_order_id': bank_order_id, 'order_id': order_id, 'old_order_id': old_order_id}
            message_id = str(uuid.uuid4())
            bank_url_info = await OrderDbManager.get_payment_status_check_url(order_id, by_order=1)
            async with httpx.AsyncClient() as client:
                bank_url = bank_url_info['check_status_url'] + bank_order_id + "&token=" + bank_url_info["bank_token"]
                _pay_state = await client.post(bank_url)
                _pay_state = _pay_state.json()
                print(_pay_state)
                if _pay_state["errorCode"] == '0' and _pay_state['orderStatus'] == 2:
                    _bank_order_id = await OrderServiceManager.add_bank_order_to_temp(bank_order_id, order_id)
                    if not _bank_order_id:
                        return
                    if renew:
                        _email = await OrderDbManager.renew_tariff_to_user_after_verify(bank_order_id, order_id,
                                                                                        old_order_id)
                        _email = _email["c_email"]
                        if not _email:
                            return
                        task = asyncio.create_task(
                            RabbitMQ.send_mails_after_check(bank_order_id, _email, message_id, renew=True))
                    else:
                        _email = await OrderDbManager.add_tariff_to_user_after_verify(bank_order_id)
                        _email = _email["c_email"]
                        task = asyncio.create_task(RabbitMQ.send_mails_after_check(bank_order_id, _email, message_id))
                        if not _email:
                            return
                    asyncio.ensure_future(task)
                    return True
            return {"status": _pay_state['actionCodeDescription']}
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def verify_order(order_id, renew=False):
        try:
            _state = await OrderDbManager.verify_order(order_id, renew)
            return _state
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def add_task_for_track(task_id, bank_order_id):
        try:
            # _order_info = json.loads(bank_order_id.decode('utf-8'))
            _bank_order_id = bank_order_id["bank_order_id"]
            _add_state = await OrderDbManager.add_task_for_track(task_id, _bank_order_id)
            return _add_state
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def renew_order_info(order_id):
        try:
            _order_info = await OrderDbManager.renew_order_info(order_id)
            if not _order_info:
                return
            return ReNewTariff(**_order_info)
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def track_rabbit_task(task_id):
        try:
            _track_task_id = await OrderDbManager.track_rabbit_task(task_id)
            return _track_task_id
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def update_rabbit_task(task_id):
        try:
            await OrderDbManager.update_rabbit_task(task_id)
            return True
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def get_download_links_for_email(order_id):
        try:
            _links = await OrderDbManager.get_download_links_for_email(order_id)
            return _links
        except Exception as e:
            print(e)
            return

    @staticmethod
    async def cron_check_pay_state():
        try:
            _pay_list = await OrderDbManager.cron_check_pay_state()
            return _pay_list
        except Exception as e:
            print(e)
            return
